﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using System.Data;

public partial class Register : System.Web.UI.Page
{
    

    protected void Page_Load(object sender, EventArgs e)
    {

    }



    [System.Web.Services.WebMethod]
    public static int registerStudent(string studNo, string studFirst, string studMiddle, string studLast, string studDob, string studCourse, string studPass) {
        MySqlConnection conn = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=STUDENT_RECO;User Id=root;password=''");
        if(checkStudentNo(studNo)== 1)
        {
            Debug.Print("1");
            return 1;
        }
        conn.Open();
        MySqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO tblstudents VALUES ('"+ studNo +"','"+ studPass +"','"+studCourse+"','"+studFirst+"','"+studMiddle+"','"+studLast+"','"+studDob+"');";
        cmd.ExecuteNonQuery();
        conn.Close();
        Debug.Print("0");
        return 0;
    }

    public static int checkStudentNo(string studentNo)
    {
        MySqlConnection conn = new MySqlConnection(@"Data Source=localhost;port=3306;Initial Catalog=STUDENT_RECO;User Id=root;password=''");
        conn.Open();
        MySqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "SELECT studNo FROM tblstudents WHERE studNo = '"+ studentNo +"';";
        cmd.ExecuteNonQuery();
        DataTable dt = new DataTable();
        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
        da.Fill(dt);
        if (dt.Rows.Count != 0)
        {
            Debug.Print("1");
            return 1;    
        }
        else
        {
            Debug.Print("0");
            return 0;
        }
    }
}